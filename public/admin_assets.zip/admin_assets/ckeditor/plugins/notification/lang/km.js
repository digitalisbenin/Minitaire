/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'notification', 'km', {
	closed: 'បាន​បិទ​ការ​ផ្ដល់​ដំណឹង។'
} );
