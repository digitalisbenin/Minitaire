
<?php $__env->startSection('title','Détails cours'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title"> Détails Cours</h1>
                    <p>Détails sur la formation</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="index.html">Accueil</a></li>
                    <li> Détails cours</li>
                </ul>
            </div>
        </div>
    </div>
</div>


<!-- Course Details Section Start -->
<div class="course-details section">
    <div class="container">
        <div class="row">
            <!-- Course Details Wrapper Start -->

            <div class="col-lg-12 col-12">
                <ul class="nav nav-tabs" id="myTab" role="tablist">

                    <?php $__currentLoopData = $chapitre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?php echo e($index == 0 ? 'active' : ''); ?>" 
                            id="chapter-<?php echo e($chapter->id); ?>-tab" 
                            data-bs-toggle="tab"
                            data-bs-target="#chapter-<?php echo e($chapter->id); ?>" 
                            type="button" 
                            role="tab" 
                            aria-controls="chapter-<?php echo e($chapter->id); ?>" 
                            aria-selected="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                            data-id="<?php echo e($chapter->id); ?>" 
                            data-title="<?php echo e($chapter->titre); ?>"> 
                        <?php echo e($chapter->titre); ?>

                    </button>
                            
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <?php $__currentLoopData = $chapitre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php echo e($index == 0 ? 'show active' : ''); ?>" id="chapter-<?php echo e($chapter->id); ?>" role="tabpanel"
                            aria-labelledby="chapter-<?php echo e($chapter->id); ?>-tab">
                            <div class="course-content">
                                <h3 class="title">Titre de la formation: <?php echo e($chapter->formation->titre); ?></h3>
                                <br>

                                <div class="course-overview">
                                    <h3 class="title"> <?php echo e($chapter->titre); ?></h3>

                                    <div class="overview-course-video">
                                        <iframe title="<?php echo e($chapter->formation->titre); ?>"
                                            src="/assets/uploads/chapitre_video/<?php echo e($chapter->video_url); ?>"></iframe>
                                    </div>

                                    <p>
                                        <?php echo e($chapter->description); ?>

                                    </p>

                                    <p><a target="bank" href="/assets/uploads/chapitre_documents/<?php echo e($chapter->document_url); ?>">lien du document</a>
                                    </p>

                                    <!-- Button trigger modal -->
                              <?php if(Auth::check()): ?>
                              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal-<?php echo e($chapter->id); ?>">
                                Faire un commentaire
                                </button>
                              <?php endif; ?>

                                <!-- Modal -->
                             <div class="modal fade" id="exampleModal-<?php echo e($chapter->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Faire un commentaire sur ce chapitre</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(url('commentaires')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <label for="exampleInputEmail1" class="form-label">Titre du chapitre</label>
                                                <input type="text" class="form-control" value="<?php echo e($chapter->titre); ?>" id="" disabled>

                                              </div>
        
                                            <div class="mb-3">
                                                <label for="exampleFormControlTextarea1" class="form-label">Commentaire</label>
                                                <textarea class="form-control" name="content" id="exampleFormControlTextarea1" rows="3"></textarea>
                                              </div>
                                            <div class="mb-3">
                                               
                                                <input type="hidden" class="form-control" name="chapitre_id" value="<?php echo e($chapter->id); ?>" id="exampleInputEmail1" aria-describedby="emailHelp">
  
                                              </div>


                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success">Envoyer</button>
                                    </div>
                                </form>
                                    </div>
                                </div>
                                </div>

                                </div>
                            </div>
                           
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
                </div>
            </div>

            
            <!-- End Course Details Wrapper -->
            <!-- Start Course Sidebar -->
            
            <!-- End Course Sidebar -->
        </div>
    </div>
</div>
<!-- Course Details Section End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Écouter l'événement de clic sur les boutons 
        $('.nav-link').on('click', function() {
            var chapterId = $(this).data('id');    
            var chapterTitle = 100; // Récupérer le titre du chapitre
           
            
            // Requête AJAX pour envoyer les données au serveur
            $.ajax({
                url: '/suivis',           // URL de la route Laravel
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',  // Inclure le token CSRF
                    chapitreId: chapterId,                 // ID du chapitre
                    taux: chapterTitle            // Titre du chapitre
                },
                success: function(response) {
                    
                    swal("",response.status,"success")
                },
                error: function(xhr, status, error) {
                    // Gestion des erreurs
                   // alert('Erreur lors de l\'enregistrement de la progression.');
                    swal("","Erreur lors de l'enregistrement de la progression.","error")
                }
            });
        });
    });
</script>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/details_cours.blade.php ENDPATH**/ ?>