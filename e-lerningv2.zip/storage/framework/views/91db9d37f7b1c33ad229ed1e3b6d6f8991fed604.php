<!-- Start Header Area -->
<header class="header navbar-area">
    <!-- Toolbar Start -->
    <div class="toolbar-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="d-flex justify-content-between align-items-center">
                        <!-- Section du texte à gauche -->
                        <div class="toolbar-text">
                            <p class="mb-0 text-white" style="text-transform: uppercase;">Direction du Service des l'Intendence des Armées</p>
                        </div>
    
                        <!-- Section des icônes sociales et du bouton Connexion à droite -->
                        <div class="d-flex justify-content-end align-items-center">
                            <!-- Section des icônes sociales -->
                            <div class="toolbar-social me-3">
                                <ul class="d-flex">
                                    <li><a href="javascript:void(0)"><i class="lni lni-facebook-original"></i></a></li>
                                    <li><a href="javascript:void(0)"><i class="lni lni-twitter-original"></i></a></li>
                                    <li><a href="javascript:void(0)"><i class="lni lni-instagram"></i></a></li>
                                    <li><a href="javascript:void(0)"><i class="lni lni-linkedin-original"></i></a></li>
                                    <li><a href="javascript:void(0)"><i class="lni lni-google"></i></a></li>
                                </ul>
                            </div>
    
                            <!-- Section du bouton Connexion -->
                            <div class="toolbar-login">
                                <?php if(auth()->guard()->guest()): ?>
                                <div class="button">
                                    <a href="/login" class="btn">Connexion</a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <!-- Toolbar End -->
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
            <div class="nav-inner">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('assets/images/logo/Logos.png')); ?>" alt="Logo">
                    </a>
                    <button class="navbar-toggler mobile-menu-btn" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                        <ul id="nav" class="navbar-nav ms-auto me-3">
                            <li class="nav-item">
                                <a class="" href="<?php echo e(url('/')); ?>"

                                    aria-expanded="false"
                                    >Accueil</a>

                            </li>
                            
                            <li class="nav-item"><a href="<?php echo e(url('/formation')); ?>">Formations</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('/forums')); ?>">Forum</a></li>

                            
                            


                            <li class="nav-item"><a href="<?php echo e(url('/documents')); ?>">Documents</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('/video')); ?>">Videos</a></li>

                            <li class="nav-item"><a href="<?php echo e(url('/contact')); ?>">Contacts</a></li>
                        </ul>


                        
                        
                      <?php if(auth()->guard()->check()): ?>
                      <div class="dropdown ">
                        <a class=" dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                            <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->prenom); ?>

                        </a>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                          
                          <li><a class="dropdown-item" href="#">Profil</a></li>
                          <li><a class="dropdown-item" href="<?php echo e(url('mes-cours')); ?>"> Mes Cours</a></li>
                          <?php if(Auth::user()->role_id == '1'||Auth::user()->role_id == '2' ): ?>
                          <li><a class="dropdown-item" href="<?php echo e(url('dashboard')); ?>">Tableau de bord</a></li>
                           <?php endif; ?>

                          <li><a class="dropdown-item" href="<?php echo e(url('mes-reunions')); ?>">Mes reunions</a></li>
                          <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Déconnexion</a></li>
                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                              <?php echo csrf_field(); ?>
                          </form>
                        </ul>
                      </div>
                </div>
                      <?php endif; ?>


                    <!-- navbar collapse -->
                </nav> <!-- navbar -->
            </div>
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</header>
<?php /**PATH C:\laragon\www\e-lerningv2\resources\views/partial/navbar.blade.php ENDPATH**/ ?>