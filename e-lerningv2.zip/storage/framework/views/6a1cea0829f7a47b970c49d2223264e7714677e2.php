
<?php $__env->startSection('title','Forums'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                
                                    
                                

<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title"> forums</h1>
                    <p>Forums de discussion</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
                    <li>Forums</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class=" h-screen">
    <div class="mt-5 " style="margin-left: 6rem; margin-right: 6rem;">
       <?php if(auth()->guard()->check()): ?>
       <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="bi bi-question-circle-fill" style="width: 24px;">
            <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"></path>
          </svg> 
          Posez votre question
        </button>
       <?php endif; ?>
         

            <!-- Modal -->
         <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Poser votre question</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('discussions')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                       

                        <div class="mb-3">
                            
                            <textarea class="form-control" name="titre" id="exampleFormControlTextarea1" rows="3"></textarea>
                          </div>
                        


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Envoyer</button>
                </div>
            </form>
                </div>
            </div>
            </div>

            </div>
        </div>
        <div class="d-flex mx-5">
            <!-- Bouton Posez votre question -->
            
           
           

            <!-- Champ de recherche -->
            <div class="ms-auto mt-3">
              
            </div>
          </div>

          
      
    <?php $__currentLoopData = $discution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex mx-5 mt-5">
      <!-- Texte principal -->
      <div  style="margin-left: 3rem; margin-right: 6rem;" >
        <a href="" class="text-decoration-none hover text-dark">
          <h1 class="h3 font-monospace"><?php echo e($value->titre); ?></h1>
        </a>
        <p class="text-left">Par <?php echo e($value->user->name); ?>  <?php echo e($value->user->prenom); ?>, <?php echo e(\Carbon\Carbon::parse($value->created_at)->translatedFormat('d F Y')); ?> </p>

        <?php if(Auth::check()): ?>
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#exampleModal-<?php echo e($value->id); ?>">
          Réponse question
          </button>
        <?php endif; ?>

          <!-- Modal -->
       <div class="modal fade" id="exampleModal-<?php echo e($value->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Répondre à la question</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <form action="<?php echo e(url('discussions-reponses')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="mb-3">
                          <label for="exampleInputEmail1" class="form-label">Question</label>
                          <input type="text" class="form-control" value="<?php echo e($value->titre); ?>" id="" disabled>

                        </div>

                      <div class="mb-3">
                          <label for="exampleFormControlTextarea1" class="form-label">Réponse</label>
                          <textarea class="form-control" name="titre" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                      <div class="mb-3">
                         
                          <input type="hidden" class="form-control" name="discution_id" value="<?php echo e($value->id); ?>" id="exampleInputEmail1" aria-describedby="emailHelp">

                        </div>


              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-success">Envoyer</button>
              </div>
          </form>
              </div>
          </div>
          </div>

          </div>
      </div>
      </div>

      <!-- Informations supplémentaires -->
      <div class="ms-auto d-flex">
        <!-- Section réponses et vues -->
        <div class="me-4">
          <p class="text-left mb-1"></p>
          <p class="text-left"></p>
        </div>

        <!-- Section image et auteur -->
        <div class="d-flex">
          <div class="me-2">
            
          </div>
          <div class="ms-auto d-flex">
            
            
        </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div style="height: 20px;"></div>

    </div>
  </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/forum.blade.php ENDPATH**/ ?>