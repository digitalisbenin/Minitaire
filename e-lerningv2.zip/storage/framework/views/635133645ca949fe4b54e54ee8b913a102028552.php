
<?php $__env->startSection('title','Accueil'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="hero-area">
    <div class="hero-slider">
        <!-- Single Slider -->
        <div class="hero-inner overlay" style="background-image: url('assets/images/hero/slider1.jpg');">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-8 offset-lg-2 col-md-12 co-12">
                        <div class="home-slider">
                            <div class="hero-text">
                                
                                <h1 class="wow fadeInUp" data-wow-delay=".5s">Bienvenue sur la platforme <br> de formation des militaires</h1>
                                <p class="wow fadeInUp" data-wow-delay=".7s"> <br> .</p>
                                <div class="button wow fadeInUp" data-wow-delay=".9s">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Single Slider -->
        <!-- Single Slider -->
        <div class="hero-inner overlay" style="background-image: url('assets/images/hero/slider-bg2.jpg');">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-8 offset-lg-2 col-md-12 co-12">
                        <div class="home-slider">
                            <div class="hero-text">
                                <h5 class="wow fadeInUp" data-wow-delay=".3s">Start to learning Today</h5>
                                <h1 class="wow fadeInUp" data-wow-delay=".5s">Innovation Paradise<br> For Students </h1>
                                <p class="wow fadeInUp" data-wow-delay=".7s">Lorem Ipsum is simply dummy text of the
                                    printing and typesetting <br> industry. Lorem Ipsum has been the industry
                                    standard
                                    <br>dummy text ever since an to impression.</p>
                                <div class="button wow fadeInUp" data-wow-delay=".9s">
                                    <a href="about-us.html" class="btn">Learn More</a>
                                    <a href="events-grid.html" class="btn alt-btn">Our Events</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Single Slider -->
        <!-- Single Slider -->
        <div class="hero-inner overlay" style="background-image: url('assets/images/hero/slider-bg3.jpg');">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-8 offset-lg-2 col-md-12 co-12">
                        <div class="home-slider">
                            <div class="hero-text">
                                <h5 class="wow fadeInUp" data-wow-delay=".3s">Start to learning Today</h5>
                                <h1 class="wow fadeInUp" data-wow-delay=".5s">Your Ideas Will Be <br> Heard & Supported</h1>
                                <p class="wow fadeInUp" data-wow-delay=".7s">Lorem Ipsum is simply dummy text of the
                                    printing and typesetting <br> industry. Lorem Ipsum has been the industry
                                    standard
                                    <br>dummy text ever since an to impression.</p>
                                <div class="button wow fadeInUp" data-wow-delay=".9s">
                                    <a href="about-us.html" class="btn">Learn More</a>
                                    <a href="#" class="btn alt-btn">Our Courses</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Single Slider -->
    </div>
</section>
<!--/ End Hero Area -->

<!-- Start Features Area -->
<section class="features">
    <div class="container-fluid">
        <div class="single-head">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-12 padding-zero">
                    <!-- Start Single Feature -->
                    <div class="single-feature">
                        <h3><a href="javascript:void(0)">Cours en vogue </a></h3>
                        <p>Les cours en vogue sont des formations éducatives qui répondent aux besoins et intérêts
                             actuels des apprenants. Ces cours reflètent les évolutions et innovations
                              dans divers domaines, offrant des compétences et connaissances recherchées.</p>
                        <div class="button">
                            <a href="<?php echo e(url('/formation')); ?>" class="btn">Voir plus <i class="lni lni-arrow-right"></i></a>
                        </div>
                    </div>
                    <!-- End Single Feature -->
                </div>
                <div class="col-lg-4 col-md-4 col-12 padding-zero">
                    <!-- Start Single Feature -->
                    <div class="single-feature">
                        <h3><a href="javascript:void(0)">Professeurs certifiés</a></h3>
                        <p>Les professeurs certifiés sont des éducateurs ayant obtenu une certification officielle attestant
                            de leurs compétences et qualifications dans un domaine spécifique. Cette certification, délivrée
                             par des organismes reconnus.</p>

                        <div class="button">
                            <a href="<?php echo e(url('/formateurs')); ?>" class="btn">Voir plus <i class="lni lni-arrow-right"></i></a>
                        </div>
                    </div>
                    <!-- End Single Feature -->
                </div>
                <div class="col-lg-4 col-md-4 col-12 padding-zero">
                    <!-- Start Single Feature -->
                    <div class="single-feature last">
                        <h3><a href="javascript:void(0)">Documents</a></h3>
                        <p>Les documents laissés à la portée des apprenants sont des ressources
                             éducatives mises à disposition pour soutenir leur apprentissage et
                              approfondir leurs connaissances. Ces documents peuvent inclure une
                               variété de matériaux pédagogiques.</p>

                        <div class="button">
                            <a href="<?php echo e(url('documents')); ?>" class="btn">Voir plus <i class="lni lni-arrow-right"></i></a>
                        </div>
                    </div>
                    <!-- End Single Feature -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /End Features Area -->


<!-- Start Courses Area -->
<section class="courses section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <div class="section-icon wow zoomIn" data-wow-delay=".4s">
                        <i class="lni lni-graduation"></i>
                    </div>
                    <h2 class="wow fadeInUp" data-wow-delay=".4s">Quelques cours</h2>
                    <p class="wow fadeInUp" data-wow-delay=".6s">Des cours variés et accessibles sont proposés afin de
                         permettre aux apprenants de développer et d’améliorer leurs compétences dans divers domaines,
                          en leur offrant des opportunités d’apprentissage adaptées à leurs besoins spécifiques et à leurs
                          objectifs personnels et professionnels.
                        </p>
                </div>
            </div>
        </div>
        <div class="single-head">
            <div class="row">
               <?php $__currentLoopData = $formation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Course -->
                <div class="single-course wow fadeInUp" data-wow-delay=".2s">
                    <div class="course-image">
                        <a href="<?php echo e(url('/details-cours/'.$value->id)); ?>"><img src="<?php echo e(asset('assets/uploads/formation_images/'.$value->image_url)); ?>"
                                alt="#"></a>
                        <p class="price"><?php echo e($value->difficulete->name); ?></p>
                    </div>
                    <div class="content">
                        <h5><a href="<?php echo e(url('/details-cours/'.$value->id)); ?>"><?php echo e($value->titre); ?></a></h5>
                        <br>
                        
                        <p style="
                                        display: -webkit-box;
                                        -webkit-line-clamp: 3;
                                        -webkit-box-orient: vertical;
                                        overflow: hidden;
                                        text-overflow: ellipsis;
                                    ">
                                        <?php echo e($value->description); ?>

                                    </p>

                    </div>
                    <div class="bottom-content">
                        <ul class="review">
                            

                        </ul>
                        <span class="tag">
                            <i class="lni lni-tag"></i>
                            <a href="javascript:void(0)"><?php echo e($value->category->name); ?></a>
                        </span>
                    </div>
                </div>
                <!-- End Single Course -->
            </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
                
                
                
                
                
            </div>
        </div>
    </div>
</section>
<!-- End Courses Area -->

<!-- Start Achivement Area -->
<section class="our-achievement section overlay">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-12">
                <div class="single-achievement wow fadeInUp" data-wow-delay=".2s">
                    <h3 class="counter"><span id="secondo1" class="countup" cup-end="500">500</span>+</h3>
                    <h4>Apprenants</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
                <div class="single-achievement wow fadeInUp" data-wow-delay=".4s">
                    <h3 class="counter"><span id="secondo2" class="countup" cup-end="70">70</span>+</h3>
                    <h4> Cours</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
                <div class="single-achievement wow fadeInUp" data-wow-delay=".6s">
                    <h3 class="counter"><span id="secondo3" class="countup" cup-end="100">100</span>%</h3>
                    <h4>Satisfaction</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-12">
                <div class="single-achievement wow fadeInUp" data-wow-delay=".6s">
                    <h3 class="counter"><span id="secondo3" class="countup" cup-end="100">100</span>+</h3>
                    <h4>Formateurs</h4>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Achivement Area -->

<!-- Start Events Area-->

<!-- End Events Area-->

<!-- Start Teachers -->

<!-- End Testimonial Area -->

<!-- Start Newsletter Area -->

<!-- /End Newsletter Area -->

<!-- Start Call To Action Area -->

<!-- /End Call To Action Area -->

<!-- Start Latest News Area -->
<div class="latest-news-area section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <div class="section-icon wow zoomIn" data-wow-delay=".4s">
                        <i class="lni lni-quotation"></i>
                    </div>
                    <h2 class="wow fadeInUp" data-wow-delay=".4s">Les cours Terminés</h2>
                    <p class="wow fadeInUp" data-wow-delay=".6s">Les cours Terminés se réfèrent aux formations  déjà terminées.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single News -->
                <div class="single-news custom-shadow-hover wow fadeInUp" data-wow-delay=".2s">
                    <div class="image">
                        <a href="#"><img class="thumb"
                                src="assets/images/blog/blog-grid1.jpg" alt="#"></a>
                    </div>
                    <div class="content-body">
                        <div class="meta-data">
                            <ul>
                                <li>
                                    <i class="lni lni-tag"></i>
                                    <a href="javascript:void(0)">Cours</a>
                                </li>
                                <li>
                                    <i class="lni lni-calendar"></i>
                                    <a href="javascript:void(0)"> 25 Janvier 2023</a>
                                </li>
                            </ul>
                        </div>
                        <h4 class="title"><a href="#">Gestion administrative
                                </a></h4>
                        <p>La gestion administrative est un ensemble de processus et d'activités visant à organiser,
                             coordonner et superviser les opérations d'une organisation. Elle joue un rôle crucial
                             dans le bon fonctionnement de toute organisation.</p>
                        <div class="button">
                            <a href="#" class="btn">Voir plus</a>
                        </div>
                    </div>
                </div>
                <!-- End Single News -->
            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single News -->
                <div class="single-news custom-shadow-hover wow fadeInUp" data-wow-delay=".4s">
                    <div class="image">
                        <a href="#"><img class="thumb"
                                src="assets/images/blog/blog-grid2.jpg" alt="#"></a>
                    </div>
                    <div class="content-body">
                        <div class="meta-data">
                            <ul>
                                <li>
                                    <i class="lni lni-tag"></i>
                                    <a href="javascript:void(0)">Cours</a>
                                </li>
                                <li>
                                    <i class="lni lni-calendar"></i>
                                    <a href="javascript:void(0)"> 10 Janvier 2023</a>
                                </li>
                            </ul>
                        </div>
                        <h4 class="title"><a href="#">Logistique
                                </a></h4>
                        <p>La logistique est le processus de planification, de mise en œuvre et de
                            contrôle du flux et du stockage efficaces des biens, des services et des
                             informations depuis le point d'origine jusqu'au point de consommation.</p>
                        <div class="button">
                            <a href="#" class="btn">Voir plus</a>
                        </div>
                    </div>
                </div>
                <!-- End Single News -->
            </div>
            <div class="col-lg-4 col-md-6 col-12">
                <!-- Single News -->
                <div class="single-news custom-shadow-hover wow fadeInUp" data-wow-delay=".6s">
                    <div class="image">
                        <a href="#"><img class="thumb"
                                src="assets/images/blog/blog-grid3.jpg" alt="#"></a>
                    </div>
                    <div class="content-body">
                        <div class="meta-data">
                            <ul>
                                <li>
                                    <i class="lni lni-tag"></i>
                                    <a href="javascript:void(0)">Education</a>
                                </li>
                                <li>
                                    <i class="lni lni-calendar"></i>
                                    <a href="javascript:void(0)"> 05 Janvier 2023</a>
                                </li>
                            </ul>
                        </div>
                        <h4 class="title"><a href="#">Renseignement
                                </a></h4>
                        <p>Le renseignement fait référence à la collecte,
                            l'analyse et l'utilisation d'informations pour soutenir la prise de décision,
                             principalement dans les contextes de sécurité nationale, de défense, et
                              parfois dans le secteur privé.</p>
                        <div class="button">
                            <a href="#" class="btn">Voir plus</a>
                        </div>
                    </div>
                </div>
                <!-- End Single News -->
            </div>
        </div>
    </div>
</div>
<!-- End Latest News Area -->

<!-- Start Clients Area -->

<!-- End Clients Area -->



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/welcome.blade.php ENDPATH**/ ?>