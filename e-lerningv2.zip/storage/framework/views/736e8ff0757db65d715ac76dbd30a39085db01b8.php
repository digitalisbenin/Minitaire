
<?php $__env->startSection('title','Documents'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Start Breadcrumbs -->
<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title">Documents</h1>
                    <p>Des documents disponible pour les apprenants</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
                    <li>Documents</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->


<!-- Teacher Details -->
<div class="teacher-details-area section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title align-center gray-bg">
                    <span>Documents</span>
                    <h2 class="wow fadeInUp" data-wow-delay=".4s">Les documents</h2>
                    <p class="wow fadeInUp" data-wow-delay=".6s"></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $resource; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12"> <!-- Ajustement pour les tailles moyennes et petites -->
                <div class="teacher-personal-info">
                    <div class="row align-items-center">
                        <div class="col-lg-3 col-md-4 col-12">
                            <div class="image">
                                <img src="<?php echo e(asset('assets/uploads/resource_images/'.$value->image_url)); ?>" alt="#">
                                <h4 class="name"><?php echo e($value->titre); ?>

                                    
                                </h4>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-8 col-12">
                            <div class="personal-social">
                                <p><?php echo e($value->description); ?></p>
                                <ul class="social">
                                    <li><a target="bank" href="/assets/uploads/resource_documents/<?php echo e($value->document_url); ?>">Lien du document</a></li>
                                    <li><a target="bank" href="/assets/uploads/resource_video/<?php echo e($value->video_url); ?>">Lien de la vidéo</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
</div>
<!-- End teacher Details -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/documents.blade.php ENDPATH**/ ?>