
<?php $__env->startSection('title','Formations'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Start Breadcrumbs -->
<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title"> formations</h1>
                    <p>Des formations de qualités</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="<?php echo e(url('/')); ?>">Accueil</a></li>
                    <li>Formations</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->


<!-- Start Courses Area -->
<section class="courses style2 section">
    <div class="container">
        <div class="row">
            <div class="col-12 ">
                <div class="section-title">
                    
                    <h2 class="wow fadeInUp" data-wow-delay=".4s">Formation</h2>
                    <p class="wow fadeInUp" data-wow-delay=".6s"></p>
                </div>
            </div>
        </div>
        <div class="single-head">
            <div class="row">
               <?php $__currentLoopData = $formation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Course -->
                <div class="single-course wow fadeInUp" data-wow-delay=".2s">
                    <div class="course-image">
                        <a href="<?php echo e(url('details-cours/'.$value->id)); ?>"><img src="<?php echo e(asset('assets/uploads/formation_images/'.$value->image_url)); ?>"
                                alt="#">
                            </a>
                            
                    </div>
                    <div class="content">
                        <p class="date"><?php echo e($value->category->name); ?> </p>

                        <p class="date"> <?php echo e($value->difficulete->name); ?></p>
                        <h5> <?php echo e($value->titre); ?></h5>
                        <br>
                        <a href="<?php echo e(url('details-cours/'.$value->id)); ?>"></a>
                        <p><?php echo e($value->description); ?></p>
                            <br>
                        <div>
                            <button class="btn btn-success ajouter-formation" data-id="<?php echo e($value->id); ?>">Ajouter</button>
                        </div>
                    </div>
                </div>
                <!-- End Single Course -->
            </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('.ajouter-formation').on('click', function() {
            var formationId = $(this).data('id'); // Récupérer l'ID de la formation
    

            $.ajax({
                url: '/mes-cours',  // URL de la route Laravel pour ajouter la formation
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',  // CSRF token pour la sécurité
                    formation_id: formationId     // ID de la formation à envoyer au serveur
                },
                success: function(response) {
                    swal("",response.status,"success")
                },
                error: function(xhr, status, error) {
                    swal("","Erreur lors de l'enregistrement de ce cours.","error")
                }
            });
        });
    });
</script>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/formations.blade.php ENDPATH**/ ?>