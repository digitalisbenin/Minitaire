

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="dashboard-body">
        <!-- Breadcrumb Start -->
    <div class="breadcrumb mb-24">
<ul class="flex-align gap-4">
    <li><a href="<?php echo e(url('dashboard')); ?>" class="text-gray-200 fw-normal text-15 hover-text-main-600">Accueil</a></li>
    <li> <span class="text-gray-500 fw-normal d-flex"><i class="ph ph-caret-right"></i></span> </li>
    <li><span class="text-main-600 fw-normal text-15">Formations</span></li>
</ul>
</div>
<!-- Breadcrumb End -->

        <!-- Course Tab Start -->
        <div class="card">
            <div class="card-body">
                <div class="mb-24 flex-between gap-16 flex-wrap-reverse">
                    <ul class="nav nav-pills common-tab gap-20" id="pills-tab" role="tablist">
                        
                    </ul>
                    <a href="<?php echo e(url('/create-formations')); ?>" class="btn btn-main rounded-pill py-7 flex-align gap-4 fw-normal">
                        <span class="d-flex text-md"><i class="ph ph-plus"></i></span>
                        Ajouter une formation
                    </a>
                </div>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-onGoing" role="tabpanel" aria-labelledby="pills-onGoing-tab" tabindex="0">
                        <div class="row g-20">
                           <?php $__currentLoopData = $formation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="col-xxl-3 col-lg-4 col-sm-6">
                            <div class="card border border-gray-100">
                                <div class="card-body p-8">
                                    <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="bg-main-100 rounded-8 overflow-hidden text-center mb-8 h-164 flex-center p-8">
                                        
                                        <img src="<?php echo e(asset('assets/uploads/formation_images/'.$value->image_url)); ?>" alt="Course Image">
                                    </a>
                                    <div class="p-8">
                                        <span class="text-13 py-2 px-10 rounded-pill bg-success-50 text-success-600 mb-16"><?php echo e($value->titre); ?></span>
                                        <h5 class="mb-0"><a href="" class="hover-text-main-600"><?php echo e($value->description); ?></a></h5>
                                        <span class="text-16  text-gray-600"> catégorie: <?php echo e($value->category->name); ?> </span>

                                        <div class="flex-align gap-8 mt-12">
                                            <span class="text-main-600 flex-shrink-0 text-13 fw-medium">32%</span>
                                            <div class="progress w-100  bg-main-100 rounded-pill h-8" role="progressbar" aria-label="Basic example" aria-valuenow="32" aria-valuemin="0" aria-valuemax="100">
                                                <div class="progress-bar bg-main-600 rounded-pill" style="width: 32%"></div>
                                            </div>
                                        </div>
                                        <span class="text-16  text-gray-600"> Difficulté: <?php echo e($value->difficulete->name); ?> </span>
                                        
                                        <a href="<?php echo e(url('/create-chapitres')); ?>" class="btn btn-outline-main rounded-pill py-9 w-100 mt-24">Ajouter un chapitre</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-completed" role="tabpanel" aria-labelledby="pills-completed-tab" tabindex="0">
                        <div class="row g-20">
                            <div class="col-xxl-3 col-lg-4 col-sm-6">
                                <div class="card border border-gray-100">
                                    <div class="card-body p-8">
                                        <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="bg-main-100 rounded-8 overflow-hidden text-center mb-8 h-164 flex-center p-8">
                                            <img src="admin/assets/images/thumbs/course-img1.png" alt="Course Image">
                                        </a>
                                        <div class="p-8">
                                            <span class="text-13 py-2 px-10 rounded-pill bg-success-50 text-success-600 mb-16">Development</span>
                                            <h5 class="mb-0"><a href="<?php echo e(url('/admin-cours-detail')); ?>" class="hover-text-main-600">Full Stack Web Development</a></h5>

                                            <div class="flex-align gap-8 mt-12">
                                                <span class="text-main-600 flex-shrink-0 text-13 fw-medium">32%</span>
                                                <div class="progress w-100  bg-main-100 rounded-pill h-8" role="progressbar" aria-label="Basic example" aria-valuenow="32" aria-valuemin="0" aria-valuemax="100">
                                                    <div class="progress-bar bg-main-600 rounded-pill" style="width: 32%"></div>
                                                </div>
                                            </div>
                                            <div class="flex-align gap-8 flex-wrap mt-16">
                                                <img src="admin/assets/images/thumbs/user-img1.png" class="w-32 h-32 rounded-circle object-fit-cover" alt="User Image">
                                                <div>
                                                    <span class="text-gray-600 text-13">Created by <a href="profile.html" class="fw-semibold text-gray-700 hover-text-main-600 hover-text-decoration-underline">Albert James</a> </span>
                                                    <div class="flex-align gap-4">
                                                        <span class="text-15 fw-bold text-warning-600 d-flex"><i class="ph-fill ph-star"></i></span>
                                                        <span class="text-13 fw-bold text-gray-600">4.9</span>
                                                        <span class="text-13 fw-bold text-gray-600">(12k)</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="btn btn-outline-main rounded-pill py-9 w-100 mt-24">Continue Classes</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-3 col-lg-4 col-sm-6">
                                <div class="card border border-gray-100">
                                    <div class="card-body p-8">
                                        <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="bg-main-100 rounded-8 overflow-hidden text-center mb-8 h-164 flex-center p-8">
                                            <img src="admin/assets/images/thumbs/course-img2.png" alt="Course Image">
                                        </a>
                                        <div class="p-8">
                                            <span class="text-13 py-2 px-10 rounded-pill bg-warning-50 text-warning-600 mb-16">Design</span>
                                            <h5 class="mb-0"><a href="<?php echo e(url('/admin-cours-detail')); ?>" class="hover-text-main-600">UI/UX Design Course</a></h5>

                                            <div class="flex-align gap-8 mt-12">
                                                <span class="text-main-600 flex-shrink-0 text-13 fw-medium">20%</span>
                                                <div class="progress w-100  bg-main-100 rounded-pill h-8" role="progressbar" aria-label="Basic example" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                                                    <div class="progress-bar bg-main-600 rounded-pill" style="width: 20%"></div>
                                                </div>
                                            </div>
                                            <div class="flex-align gap-8 flex-wrap mt-16">
                                                <img src="admin/assets/images/thumbs/user-img2.png" class="w-32 h-32 rounded-circle object-fit-cover" alt="User Image">
                                                <div>
                                                    <span class="text-gray-600 text-13">Created by <a href="profile.html" class="fw-semibold text-gray-700 hover-text-main-600 hover-text-decoration-underline">Albert James</a> </span>
                                                    <div class="flex-align gap-4">
                                                        <span class="text-15 fw-bold text-warning-600 d-flex"><i class="ph-fill ph-star"></i></span>
                                                        <span class="text-13 fw-bold text-gray-600">4.9</span>
                                                        <span class="text-13 fw-bold text-gray-600">(12k)</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="btn btn-outline-main rounded-pill py-9 w-100 mt-24">Continue Classes</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xxl-3 col-lg-4 col-sm-6">
                                <div class="card border border-gray-100">
                                    <div class="card-body p-8">
                                        <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="bg-main-100 rounded-8 overflow-hidden text-center mb-8 h-164 flex-center p-8">
                                            <img src="admin/assets/images/thumbs/course-img3.png" alt="Course Image">
                                        </a>
                                        <div class="p-8">
                                            <span class="text-13 py-2 px-10 rounded-pill bg-danger-50 text-danger-600 mb-16">Frontend</span>
                                            <h5 class="mb-0"><a href="<?php echo e(url('/admin-cours-detail')); ?>" class="hover-text-main-600">React Native Courese</a></h5>

                                            <div class="flex-align gap-8 mt-12">
                                                <span class="text-main-600 flex-shrink-0 text-13 fw-medium">45%</span>
                                                <div class="progress w-100  bg-main-100 rounded-pill h-8" role="progressbar" aria-label="Basic example" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100">
                                                    <div class="progress-bar bg-main-600 rounded-pill" style="width: 45%"></div>
                                                </div>
                                            </div>
                                            <div class="flex-align gap-8 flex-wrap mt-16">
                                                <img src="admin/assets/images/thumbs/user-img3.png" class="w-32 h-32 rounded-circle object-fit-cover" alt="User Image">
                                                <div>
                                                    <span class="text-gray-600 text-13">Created by <a href="profile.html" class="fw-semibold text-gray-700 hover-text-main-600 hover-text-decoration-underline">Albert James</a> </span>
                                                    <div class="flex-align gap-4">
                                                        <span class="text-15 fw-bold text-warning-600 d-flex"><i class="ph-fill ph-star"></i></span>
                                                        <span class="text-13 fw-bold text-gray-600">4.9</span>
                                                        <span class="text-13 fw-bold text-gray-600">(12k)</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(url('/admin-cours-detail')); ?>" class="btn btn-outline-main rounded-pill py-9 w-100 mt-24">Continue Classes</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-saved" role="tabpanel" aria-labelledby="pills-saved-tab" tabindex="0">
                         <div class="row g-20">
                            
                            
                            
                            
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- Course Tab End -->

        <!-- Recommended Course Start -->
        <div class="card mt-24">
            <div class="card-body">
                

                

                <div class="flex-between flex-wrap gap-8 mt-20">
                    <a href="#" class="btn btn-outline-gray rounded-pill py-9 flex-align gap-4">
                        <span class="d-flex text-xl"><i class="ph ph-arrow-left"></i></span>
                        Previous
                    </a>

                    <ul class="pagination flex-align flex-wrap">
                        <li class="page-item active">
                            <a class="page-link h-44 w-44 flex-center text-15 rounded-8 fw-medium" href="#">1</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link h-44 w-44 flex-center text-15 rounded-8 fw-medium" href="#">2</a>
                        </li>
                        
                        </li>
                    </ul>

                    <a href="#" class="btn btn-outline-main rounded-pill py-9 flex-align gap-4">
                        Next <span class="d-flex text-xl"><i class="ph ph-arrow-right"></i></span>
                    </a>
                </div>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<script>
    $('.wishlist-btn').on('click', function () {
        $(this).toggleClass('bg-danger-600 text-white')
    });
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/admin/cours/index.blade.php ENDPATH**/ ?>