<!-- Start Header Area -->
<header class="header style2 navbar-area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
            <div class="nav-inner">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="assets/images/logo/Logos.png" alt="Logo">
                    </a>
                    <button class="navbar-toggler mobile-menu-btn" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                        <span class="toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                        <ul id="nav" class="navbar-nav ms-auto">
                            <li class="nav-item">
                                <a class="" href="<?php echo e(url('/')); ?>"

                                    aria-expanded="false"
                                    >Accueil</a>

                            </li>
                            <li class="nav-item">
                                <a class=" " href="<?php echo e(url('/cours')); ?>"

                                    aria-controls="navbarSupportedContent" aria-expanded="false"
                                   >Cours</a>

                            </li>
                            <li class="nav-item"><a href="<?php echo e(url('/formation')); ?>">Formations</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('/')); ?>">Forums</a></li>
                            
                            


                            <li class="nav-item"><a href="<?php echo e(url('/documents')); ?>">Documents</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('/video')); ?>">Videos</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>

                                           </ul>
                        
                    </div> <!-- navbar collapse -->
                </nav> <!-- navbar -->
            </div>
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</header>
<?php /**PATH C:\laragon\www\e-lerning\resources\views/partial/navbar2.blade.php ENDPATH**/ ?>