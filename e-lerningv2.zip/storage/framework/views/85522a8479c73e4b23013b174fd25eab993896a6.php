
<?php $__env->startSection('title','Videos'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Start Breadcrumbs -->
<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title">Video </h1>
                    <p>Voir les vidéo lié au cours</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="<?php echo e(('/')); ?>">Accueil</a></li>
                    <li>Video </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->

<section class="courses section">
    <div class="container">
        
        <div class="single-head">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Start Single Course -->
                    <div class="single-course wow fadeInUp" data-wow-delay=".2s">
                        <div class="course-image">
                            <a href="<?php echo e(url('/details-cours')); ?>"><img src="assets/images/courses/courses-1.jpg"
                                    alt="#"></a>
                            <p class="price"></p>
                        </div>
                        <div class="content">
                            <h3><a href="<?php echo e(url('/details-cours')); ?>">L'informatique</a></h3>
                            <p>L'informatique est la science qui traite du traitement, du stockage et de la transmission de
                                 l'information par des moyens électroniques</p>
                        </div>
                       
                    </div>
                    <!-- End Single Course -->
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Start Single Course -->
                    <div class="single-course wow fadeInUp" data-wow-delay=".4s">
                        <div class="course-image">
                            <a href="<?php echo e(url('/details-cours')); ?>"><img src="assets/images/courses/courses-2.jpg"
                                    alt="#"></a>
                            <p class="price"></p>
                        </div>
                        <div class="content">
                            <h3><a href="<?php echo e(url('/details-cours')); ?>">Gestion d'entreprise</a></h3>
                            <p>La gestion d'entreprise est la pratique consistant à diriger et à administrer les opérations d'une organisation pour atteindre ses objectifs</p>
                        </div>
                      
                    </div>
                    <!-- End Single Course -->
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Start Single Course -->
                    <div class="single-course wow fadeInUp" data-wow-delay=".6s">
                        <div class="course-image">
                            <a href="<?php echo e(url('/details-cours')); ?>"><img src="assets/images/courses/courses-3.jpg"
                                    alt="#"></a>
                            <p class="price"></p>
                        </div>
                        <div class="content">
                            <h3><a href="<?php echo e(url('/details-cours')); ?>">Aéronautique</a></h3>
                            <p>L'aéronautique est la science et la pratique de la conception, de la construction, et de l'exploitation des aéronefs.</p>
                        </div>
                     
                    </div>
                    <!-- End Single Course -->
                </div>
               
               
        
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerning\resources\views/video.blade.php ENDPATH**/ ?>