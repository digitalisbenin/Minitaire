<aside class="sidebar">
    <!-- sidebar close btn -->
     <button type="button" class="sidebar-close-btn text-gray-500 hover-text-white hover-bg-main-600 text-md w-24 h-24 border border-gray-100 hover-border-main-600 d-xl-none d-flex flex-center rounded-circle position-absolute"><i class="ph ph-x"></i></button>
    <!-- sidebar close btn -->

    <a href="<?php echo e(url('/')); ?>" class="sidebar__logo text-center p-20 position-sticky inset-block-start-0 bg-white w-100 z-1 pb-10">
        <img src="<?php echo e(asset('assets/images/logo/Logos.png')); ?>" alt="Logo">
    </a>

    <div class="sidebar-menu-wrapper overflow-y-auto scroll-sm">
        <div class="p-20 pt-10">
            <ul class="sidebar-menu">
                <?php if(Auth::user()->role_id == '1'): ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('/dashboard')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-squares-four"></i></span>
                        <span class="text">Statistique</span>
                        
                    </a>

                </li>
                <?php endif; ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('/formations')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-graduation-cap"></i></span>
                        <span class="text">Formations</span>
                    </a>

                </li>
                <?php if(Auth::user()->role_id == '1' ): ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('/apprenants')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-users-three"></i></span>
                        <span class="text">Apprenants</span>
                    </a>
                </li>

                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('/categories')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-clipboard-text"></i></span>
                        <span class="text">Categories</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('chapitres')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-users"></i></span>
                        <span class="text">Chapitres</span>
                    </a>
                </li>
                <?php if(Auth::user()->role_id == '1' ): ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('difficultes')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-books"></i></span>
                        <span class="text">Difficultés</span>
                    </a>
                </li>

                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('admin-formateurs')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-bookmarks"></i></span>
                        <span class="text">Formateurs</span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('ressources')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-books"></i></span>
                        <span class="text">Ressources</span>
                    </a>
                </li>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('videos')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-coins"></i></span>
                        <span class="text">Vidéos</span>
                    </a>
                </li>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('commentaires')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-chart-bar"></i></span>
                        <span class="text">Commentaire</span>
                    </a>
                </li>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('suivis')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-calendar-dots"></i></span>
                        <span class="text">Suivi</span>
                    </a>
                </li>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('visio-conferences')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-calendar-dots"></i></span>
                        <span class="text">Visio Conférence</span>
                    </a>
                </li>
                <li class="sidebar-menu__item">
                    <a href="<?php echo e(url('meets')); ?>" class="sidebar-menu__link">
                        <span class="icon"><i class="ph ph-calendar-dots"></i></span>
                        <span class="text">Meet</span>
                    </a>
                </li>
                

               
            </ul>
        </div>
        
    </div>

</aside>
<?php /**PATH C:\laragon\www\e-lerningv2\resources\views/partial/sidebar.blade.php ENDPATH**/ ?>