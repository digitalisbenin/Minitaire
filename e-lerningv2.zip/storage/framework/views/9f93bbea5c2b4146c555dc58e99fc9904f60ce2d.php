
<?php $__env->startSection('title','Videos'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- Start Breadcrumbs -->
<div class="breadcrumbs overlay">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 offset-lg-2 col-md-12 col-12">
                <div class="breadcrumbs-content">
                    <h1 class="page-title">Video </h1>
                    <p>Voir les vidéo lié au cours</p>
                </div>
                <ul class="breadcrumb-nav">
                    <li><a href="<?php echo e(('/')); ?>">Accueil</a></li>
                    <li>Video </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- End Breadcrumbs -->

<section class="courses section">
    <div class="container">
        
        <div class="single-head">
            <div class="row">
               <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-lg-4 col-md-6 col-12">
                <!-- Start Single Course -->
                <div class="single-course wow fadeInUp" data-wow-delay=".2s">
                    <div class="">

                        <iframe title="<?php echo e($value->titre); ?>"
                            src="/assets/uploads/video_video/<?php echo e($value->video_url); ?>"
                            style="width: 100%; height: auto;" frameborder="0" allowfullscreen></iframe>




                    </div>
                    <div class="content">
                        <h3><a href="#"><?php echo e($value->titre); ?></a></h3>
                        <p><?php echo e($value->description); ?></p>
                    </div>

                </div>

            </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                


            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-lerningv2\resources\views/video.blade.php ENDPATH**/ ?>