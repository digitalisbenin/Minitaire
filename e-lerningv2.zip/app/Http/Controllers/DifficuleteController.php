<?php

namespace App\Http\Controllers;

use App\Models\Difficulete;
use Illuminate\Http\Request;

class DifficuleteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $difficulete=Difficulete::all();
        return view('admin.difficulte.index',compact('difficulete'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.difficulte.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
           'name' => 'required|max:255',
            'description' => 'nullable',
        ]);
        $commentaire = Difficulete::create($validatedData);

        return redirect('/difficultes')->with('success', 'Difficultés créée avec succès!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Difficulete  $difficulete
     * @return \Illuminate\Http\Response
     */
    public function show(Difficulete $difficulete)
    {
        return view('', compact('difficulete'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Difficulete  $difficulete
     * @return \Illuminate\Http\Response
     */
    public function edit( $id)
    {
        $difficulte = Difficulete::findOrFail($id);
        return view('admin.difficulte.edit',compact('difficulte')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Difficulete  $difficulete
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:255',
             'description' => 'nullable',
         ]);
         $difficulte = Difficulete::findOrfail($id);
         $difficulte->name = $request->name;
         $difficulte->description = $request->description;
         $difficulte->save();
         return redirect('/difficultes')->with('success', 'Difficulté mise à jour avec succès!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Difficulete  $difficulete
     * @return \Illuminate\Http\Response
     */
    public function destroy(Difficulete $difficulete, $id)
    {
        $categori = Difficulete::findOrfail($id);
        $categori->delete();
        session()->flash('success', 'Suppression de la difficulté réussie !');
        return redirect('/difficultes')->with('success', 'Difficulté supprimée avec succès!');
    }
}
